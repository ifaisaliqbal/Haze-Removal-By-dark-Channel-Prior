function subplotImages( im1, im2 )
%SUBPLOTIMAGES Summary of this function goes here
%   Detailed explanation goes here

    subplot(1,2,1);
    imshow(im1);
    subplot(1,2,2);
    imshow(im2);

end

